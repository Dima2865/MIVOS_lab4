# MQTTClient
Simple Android MQTT Client works with hivemq

Use http://www.hivemq.com to test work.
Subcribe and publish topic: **testtopic/AAE230**
