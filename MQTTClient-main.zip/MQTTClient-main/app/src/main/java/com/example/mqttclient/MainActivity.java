package com.example.mqttclient;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.eclipse.paho.android.service.*;
import org.eclipse.paho.client.mqttv3.*;

import java.io.UnsupportedEncodingException;

public class MainActivity extends AppCompatActivity {
    private String TAG = "MainActivity";
    private EditText textMessage, subscribeTopic, unSubscribeTopic, incText;
    private Button publishMessage, subscribe, unSubscribe, check;

    private MqttAndroidClient client = null;

    private String topic;

    private String clientId;

    private void reConnect()
    {
        client = new MqttAndroidClient(this.getApplicationContext(),
                "tcp://broker.hivemq.com:1883", clientId);
        try {
            //client.unsubscribe(topic);
            client.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) {
                }

                @Override
                public void messageArrived(String _topic, MqttMessage message) throws Exception {
                    String m = message.toString();
                    Toast toast = Toast.makeText(getApplicationContext(), m, Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                    toast.show();
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
                }
            });
            IMqttToken token = client.connect();
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken iMqttToken) {
                    Toast toast = Toast.makeText(getApplicationContext(),
                            "Успешно подключились к серверу", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                    toast.show();
                    int qos = 0;
                    IMqttToken subToken = null;
                    try {
                        subToken = client.subscribe(topic, qos);
                    } catch (MqttException e) {
                        e.printStackTrace();
                    }
                    subToken.setActionCallback(new IMqttActionListener() {
                        @Override
                        public void onSuccess(IMqttToken asyncActionToken) {
                            Toast toast = Toast.makeText(getApplicationContext(),
                                    "Успешно подключились к топику", Toast.LENGTH_SHORT);
                            toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                            toast.show();
                        }

                        @Override
                        public void onFailure(IMqttToken asyncActionToken,
                                              Throwable exception) {
                            Toast toast = Toast.makeText(getApplicationContext(),
                                    "Ошибка подключения к топику", Toast.LENGTH_SHORT);
                            toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                            toast.show();
                        }
                    });
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken,
                                      Throwable exception) {
                    Toast toast = Toast.makeText(getApplicationContext(),
                            "Ошибка подключения к серверу", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                    toast.show();
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textMessage = (EditText) findViewById(R.id.textMessage);
        publishMessage = (Button) findViewById(R.id.publishMessage);

        subscribe = (Button) findViewById(R.id.subscribe);
        subscribeTopic = (EditText) findViewById(R.id.subscibeTopic);

        clientId = MqttClient.generateClientId();

        topic = "gusynin/#";

        reConnect();

        publishMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                try {
//                    byte[] encodedPayload = textMessage.getText().toString().getBytes("UTF-8");
//                    MqttMessage message = new MqttMessage(encodedPayload);
//                    client.publish(topic, message);
//                } catch (UnsupportedEncodingException | MqttException e) {
//                    e.printStackTrace();
//                }
                int i = 0;
                while (i != 60) {
                    int sens1 = (int) (Math.random()*200 - 100);
                    int sens2 = (int) (Math.random()*(600+1)) - 200;

                    String s1 = String.valueOf(sens1);
                    String s2 = String.valueOf(sens2);

                    topic = "gusynin/sens1";
                    try {
                        byte[] encodedPayload = s1.getBytes("UTF-8");
                        MqttMessage message = new MqttMessage(encodedPayload);
                        client.publish(topic, message);
                    } catch (UnsupportedEncodingException | MqttException e) {
                        e.printStackTrace();
                    }

                    topic = "gusynin/sens2";
                    try {
                        byte[] encodedPayload = s2.getBytes("UTF-8");
                        MqttMessage message = new MqttMessage(encodedPayload);
                        client.publish(topic, message);
                    } catch (UnsupportedEncodingException | MqttException e) {
                        e.printStackTrace();
                    }

                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    i++;
                }
            }
        });

        subscribe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    //client.unsubscribe(topic);
                    topic = subscribeTopic.getText().toString();
                    reConnect();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}